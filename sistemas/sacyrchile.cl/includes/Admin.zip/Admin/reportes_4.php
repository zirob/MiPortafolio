<?php

//Consulta que contiene el sql
$msg="";
$error="";

$sql ="SELECT p.*,df.descripcion_familia ,ds.descripcion_subfamilia   FROM productos_new p , familia df, subfamilia ds
WHERE  p.rut_empresa='".$_SESSION['empresa']."' AND  df.id_familia=p.id_familia AND ds.id_subfamilia=p.id_subfamilia ";




//Filtros
if(!empty($_POST['codbar_productonew']))
$sql.=" AND p.codbar_productonew like'%".$_POST['codbar_productonew']."%' ";

if(!empty($_POST['descripcion']))
$sql.=" AND p.descripcion like'%".$_POST['descripcion']."%' ";

if(!empty($_POST['codigo_interno']))
$sql.=" AND p.codigo_interno like'%".$_POST['codigo_interno']."%' ";


if(!empty($_POST['descripcion_familia']))
$sql.=" AND df.descripcion_familia like'%".$_POST['descripcion_familia']."%' ";


if(!empty($_POST['descripcion_subfamilia']))
$sql.=" AND ds.descripcion_subfamilia like'%".$_POST['descripcion_subfamilia']."%' ";



if(!empty($_POST['pasillo']))
$sql.=" AND p.pasillo like'%".$_POST['pasillo']."%' ";

if(!empty($_POST['casillero']))
$sql.=" AND p.casillero like'%".$_POST['casillero']."%' ";

if(!empty($_POST['observaciones']))
$sql.=" AND p.observaciones like'%".$_POST['observaciones']."%' ";


$sql.=" AND 1=1 ";




//Efectua la Consulta
$res = mysql_query($sql,$con);
?>
    <style>
	.fo
	{
		border:1px solid #09F;
		background-color:#FFFFFF;
		color:#000066;
		font-size:11px;
		font-family:Tahoma, Geneva, sans-serif;
		width:80%;
		text-align:center;
	}
	
	</style>
    <br /><br />
    <form action="?cat=4&sec=4&filtro=1" method="POST">
   
<table id="list_registros" style=" border-collapse:collapse" border="1" >

    <tr  style='font-family:tahoma;font-size:12px;'>
        <td style="text-align:left; font-weight:bold; ">Filtro:</td>
        <td style="text-align:center"><input name='codbar_productonew' value='<? echo $_POST['codbar_productonew']?>' class="fo" style="width:50px;"></td>
        <td style="text-align:center">
        <input name='descripcion' value='<? echo $_POST['descripcion']?>' class="fo" style="width:50px;">   
        </td>
        <td style="text-align:center">
       <input name='codigo_interno' value='<? echo $_POST['codigo_interno']?>' class="fo" style="width:50px;">
        </td>
        
         <td style="text-align:center">
		<input name='descripcion_familia' value='<? echo $_POST['descripcion_familia']?>' class="fo" style="width:50px;">
        </td>
        
        <td style="text-align:center">
        <input name='descripcion_subfamilia' value='<? echo $_POST['descripcion_subfamilia']?>' class="fo" style="width:50px;">
        </td>
        
        <td style="text-align:center">
        <input name='pasillo' value='<? echo $_POST['pasillo']?>' class="fo" style="width:50px;">
        </td>
        
        <td style="text-align:center">
        <input name='casillero' value='<? echo $_POST['casillero']?>' class="fo" style="width:50px;">
        </td>
        
        <td style="text-align:center">
        <input name='observaciones' value='<? echo $_POST['observaciones']?>' class="fo" style="width:100px;">
        </td>
    	
        <td style="text-align:right" colspan="4"><input type="Submit" value="Filtrar" style="background-color:#006; color:#fff; font-size:12px; font-family:Tahoma, Geneva, sans-serif; margin-right:5px; width:100px; height:25px; border-radius:0.5em;"></td>
    </tr>
    <tr  style="background-color:rgb(0,0,255); color:rgb(255,255,255); font-family:Tahoma; font-size:12px;">
        <td style="text-align:center; ">#</td>
        <td style="text-align:center; ">Codigo de<br /> Barras</td>
        <td style="text-align:center">Descripción</td>
        <td style="text-align:center">Código Interno</td>
        <td style="text-align:center">Familia</td>
        <td style="text-align:center">SubFamilia</td>
        <td style="text-align:center">Pasillo</td>
        <td style="text-align:center">Casillero</td>
        <td style="text-align:center">Observación</td>
        <td style="text-align:center"></td>
        <td style="text-align:center"></td>
        <td style="text-align:center"></td>
        <td style="text-align:center"></td>
        <!--<td width="100px">Editar</td> -->
    </tr>    

<?

	//Desempilamos los datos
	$i=1;
	while($row=mysql_fetch_array($res))
	{
    echo "<tr   style='font-family:tahoma;font-size:12px;'>";
    echo "    <td style='text-align:center'>".$i++."</td>";
    echo "    <td style='text-align:center'>".$row['codbar_productonew']."</td>";
    echo "    <td style='text-align:center'>".$row['descripcion']."</td>";
    echo "    <td style='text-align:center'>".$row['codigo_interno']."</td>";
	echo "    <td style='text-align:center'>".$row['descripcion_familia']."</td>";
    echo "    <td style='text-align:center' >".$row['descripcion_subfamilia']."</td>";
    echo "    <td style='text-align:center'>".$row['pasillo']."</td>";
	echo "    <td style='text-align:center'>".$row['casillero']."</td>";
    echo "    <td style='text-align:center' >".$row['observaciones']."</td>";
	echo "    <td style='text-align: center;'>
				    
				</td>";
	echo "    <td style='text-align: center;'>
				   
				</td>";
	echo "    <td style='text-align: center;'>
				</td>";
	echo "    <td style='text-align: center;'>
				   
				</td>";
    echo "</tr>";
	}
 ?>


</table>
</form>
<form action="includes/Admin/productos_excel.php" method="POST">     
            <input type="hidden" name="sql" id="sql" hidden="hidden" value="<?  echo $sql; ?>">

            <table align="center">
            <tr><td>
           <input type="submit" value="Exportar a Excel"></td></tr>
            </table>
             </form>