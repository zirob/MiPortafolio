<?php
$qry="";
if(isset($_GET['filtro']) && $_GET['filtro']==1){

    // $qry = "SELECT * FROM productos WHERE rut_empresa = '".$_SESSION['empresa']."' ORDER BY descripcion";
    $qry = "SELECT cod_producto, rut_empresa, descripcion, usuario_ingreso, fecha_ingreso, f.id_familia, f.descripcion_familia, s.id_subfamilia, s.descripcion_subfamilia   ";
    // $qry.= "FROM productos AS p, familia AS f ";
    $qry.= "FROM productos p inner join familia f inner join subfamilia s ";
    $qry.= "WHERE f.id_familia=p.id_familia AND  s.id_subfamilia=p.id_subfamilia AND rut_empresa = '".$_SESSION['empresa']."' ";

    if(!empty($_POST['codigo_producto']) && $_POST['codigo_producto']!=""){
        $qry .= " and cod_producto like '%".$_POST['codigo_producto']."%'";
    }
    if(!empty($_POST['descripcion']) && $_POST['descripcion']!=""){
        $qry .= " and descripcion like '%".$_POST['descripcion']."%'";
    }

    if(!empty($_POST['familia']) && $_POST['familia']!=""){
        $qry .= " and p.id_familia='".$_POST['familia']."'";
        $row["id_familia"] = $_POST["familia"]; 
     }

     if(!empty($_POST['subfamilia']) && $_POST['subfamilia']!=""){
        $qry .= " and s.id_subfamilia='".$_POST['subfamilia']."'";
        $row["id_subfamilia"] = $_POST["subfamilia"]; 
     }
    
    $qry.=" ORDER BY descripcion";

}else{
    // $qry = "SELECT * FROM productos WHERE rut_empresa = '".$_SESSION['empresa']."' ORDER BY descripcion";
    $qry = "SELECT cod_producto, rut_empresa, descripcion, usuario_ingreso, fecha_ingreso, f.id_familia, f.descripcion_familia, s.id_subfamilia, s.descripcion_subfamilia   ";
    // $qry.= "FROM productos AS p, familia AS f ";
    $qry.= "FROM productos p inner join familia f inner join subfamilia s ";
    $qry.= "WHERE f.id_familia=p.id_familia AND  s.id_subfamilia=p.id_subfamilia AND rut_empresa = '".$_SESSION['empresa']."' ";
}   
    // echo "<br>".$qry."<br>";
$res = mysql_query($qry,$con);
?>



<table id="list_registros">
    <tr>
        <td id="titulo_tabla" colspan="7"></td>
        
    </tr>
</table>

<style>
.fo
{
  border:1px solid #09F;
  background-color:#FFFFFF;
  color:#000066;
  font-size:11px;
  font-family:Tahoma, Geneva, sans-serif;
  width:90%;
  text-align:center;
}
</style>
<table id="list_registros" border="1" style="border-collapse:collapse;" >
    <form action="?cat=4&sec=6&filtro=1" method="POST">

    <tr id="titulo_reg" style="background-color: #fff;">
        <td width="20px" style="font-family:Tahoma; font-size:12px;text-align:center;">Filtro:</td>
        <td  width="120px"  style="font-family:Tahoma; font-size:12px;text-align:center;">
            <input type="text"  id="codigo_producto" value='<?=$_POST["codigo_producto"]?>' style='border:1px solid #09F;background-color:#FFFFFF;color:#000066;font-size:11px;font-family:Tahoma, Geneva, sans-serif;width:90%;' name="codigo_producto">
        </td>
        <td width="180px" style="text-align:center;"><input class="fo" type="text" id="descripcion" value='<?=$_POST["descripcion"]?>' name="descripcion"></td>
        <td width="120px"style="text-align:center;"><select name="familia"   class="fo">
<?                
                $sql2 = "SELECT * FROM familia WHERE 1=1 ORDER BY id_familia ";
                $res2 = mysql_query($sql2,$con);
?>
                <option value='0' <? if (isset($_POST["familia"]) == 0) echo 'selected'; ?> class="fo">---</option>
<?php              
                while($row2 = mysql_fetch_assoc($res2)){
?>
                   <option value='<? echo $row2["id_familia"]; ?>' <? if ($row2['id_familia'] == $_POST['familia']) echo "selected"; ?> class="fo"><?  echo $row2["descripcion_familia"];?></option>
<?php
                }
?>
            </select>
        </td>
        <td width="120px" style="text-align:center;"><select name="subfamilia"   class="fo">
<?                
                $sql2 = "SELECT * FROM subfamilia WHERE 1=1 ORDER BY id_subfamilia ";
                $res2 = mysql_query($sql2,$con);
?>
                <option value='0' <? if (isset($_POST["subfamilia"]) == 0) echo 'selected'; ?> class="fo">---</option>
<?php              
                while($row2 = mysql_fetch_assoc($res2)){
?>
                   <option value='<? echo $row2["id_subfamilia"]; ?>' <? if ($row2['id_subfamilia'] == $_POST['subfamilia']) echo "selected"; ?> class="fo"><?  echo $row2["descripcion_subfamilia"];?></option>
<?php
                }
?>
        </td>
        <td colspan="2" style="text-align: center;"><input type="submit" value="Filtrar" style="background-color:#006; color:#fff; font-size:12px; font-family:Tahoma, Geneva, sans-serif; margin-right:10px; width:90px; height:20px; border-radius:0.5em;"></td>
    </tr>    
    </form>
    <tr id="titulo_reg" style="background-color:rgb(0,0,255); color:rgb(255,255,255); font-family:Tahoma; font-size:12px;text-align:center;">
        <td width="20px">#</td>
        <td >Codigo</td>
        <td>Descripción</td>
        <td>Familia</td>
        <td>SubFamilia</td>
        <td width="30px"></td>
        <td width="30px"></td>
    </tr>    

<?
    if(mysql_num_rows($res)!=null){
        $i=1;
        while($row = mysql_fetch_assoc($res)){
?>
                <!-- Detalle -->
                <tr style="font-size:11px; font-family:Tahoma, Geneva, sans-serif; background-color:rgb(243,243,243);">
                    <td><?echo $i;$i++;?></td>
                    <td><?=$row['cod_producto']; ?></td>
                    <td><?=$row['descripcion']; ?></td>
                    <td style="text-align: center;"><?=$row["descripcion_familia"]?></td>
                    <td style="text-align: center;"><?=$row["descripcion_subfamilia"]?></td>
                    <td colspan="2"></td>
                </tr>
<?php 
        }

    }else{
?>
         <tr  id="mensaje-sin-reg"  style="color:rgb(255,255,255); font-family:Tahoma, Geneva, sans-serif; ; font-size:12px;">
            <td colspan="10">No existen Productos para ser Desplegados</td>
        </tr>
<? 
    }
?>
</table>
<form action="includes/Admin/activos_excel.php" method="POST">     
            <input type="hidden" name="sql" id="sql" hidden="hidden" value="<?  echo $qry; ?>">

            <table align="center">
            <tr><td>
           <input type="submit" value="Exportar a Excel"></td></tr>
            </table>
             </form>