<?php
if(isset($_GET['filtro']) && $_GET['filtro']==1){
    $sql = "SELECT * FROM cabecera_oc WHERE rut_empresa = '".$_SESSION['empresa']."'";
    
    if(isset($_POST['fecha']) && $_POST['fecha']!=""){
        $sql.=" and fecha_oc='".date("Y-m-d",strtotime($_POST['fecha']))."'";
    }
    
    if(isset($_POST['solicitante']) && $_POST['solicitante']!=""){
        $sql.=" and solicitante like '%".$_POST['solicitante']."%'";
    }
    
    if(isset($_POST['concepto']) && $_POST['concepto']!=""){
        $sql.=" and concepto=".$_POST['concepto'];
    }
    
    if(isset($_POST['centro_costo']) && $_POST['centro_costo']!=""){
        $sql.=" and centro_costos=".$_POST['centro_costo'];
    }
    
    if(isset($_POST['estado']) && $_POST['estado']!=""){
        $sql.=" and estado_oc=".$_POST['estado'];
    }
    
    $sql.=" ORDER BY fecha_oc";
}else{
    $sql = "SELECT * FROM cabecera_oc WHERE rut_empresa = '".$_SESSION['empresa']."' ORDER BY fecha_oc";
}
$res = mysql_query($sql,$con);

?>

  <style>
	.fo
	{
		border:1px solid #09F;
		background-color:#FFFFFF;
		color:#000066;
		font-size:11px;
		font-family:Tahoma, Geneva, sans-serif;
		width:80%;
		text-align:center;
	}
	
	</style>
<table id="list_registros" er="0" style="border-collapse:collapse; margin-top:10px;">

    <tr id="titulo_reg" style="background-color: #fff;">
        <form action="?cat=4&sec=1&filtro=1" method="POST">
        <td  style="font-family:Tahoma; font-size:12px;"><label>Filtro:</label></td>
        <td  style="text-align:center;"><input type="text" size="10" name="fecha" class="fo" value='<?=$_POST['fecha'];?>'></td>
        <td  style="text-align:center;"><input type="text" size="15" name="solicitante" class="fo" value='<?=$_POST['solicitante'];?>'></td>
        <td  style="text-align:center;">
        <select name="concepto" class="fo">
        <option value=""   class="fo">---</option>
        <option value="1"  class="fo"<? if($_POST['concepto']==1) echo " selected" ;?>>Compra</option>
        <option value="2"  class="fo"<? if($_POST['concepto']==2) echo " selected" ;?>>Mantenci&oacute;n</option>
        <option value="3"  class="fo"<? if($_POST['concepto']==3) echo " selected" ;?>>Reparaci&oacute;n</option>
        <option value="4"  class="fo"<? if($_POST['concepto']==4) echo " selected" ;?>>Servicios</option>
        <option value="5"  class="fo"<? if($_POST['concepto']==5) echo " selected" ;?>>Activos</option>
        <option value="6"  class="fo"<? if($_POST['concepto']==6) echo " selected" ;?>>Repuestos</option>
        <option value="7"  class="fo"<? if($_POST['concepto']==7) echo " selected" ;?>>Fabricacion</option>
        </select>
        </td>
        <td  style="text-align:center;"><select name="centro_costo"  class="fo">
                <option value=""  class="fo">---</option>
            <?
                $s = "SELECT * FROM centros_costos ORDER BY descripcion_cc";
                $r = mysql_query($s,$con);
                
                while($roo = mysql_fetch_assoc($r)){
                    ?>  <option value="<?=$roo['Id_cc'];?>"   <? if($_POST['centro_costo']==$roo['Id_cc']) echo " selected" ;?> class="fo"><?=$roo['descripcion_cc'];?></option> <?    
                }
        
                ?>
            </select>    
        </td>
         <td></td>
         <td  style="text-align:center;"><select name="estado" style="width:100px;" class="fo">
                 <option value="">---</option>
                 <option value="1"  class="fo"<? if($_POST['estado']==1) echo " selected" ;?>>Abierta</option>
                 <option value="2"  class="fo"<? if($_POST['estado']==2) echo " selected" ;?>>Pendiente</option>
                 <option value="4"  class="fo"<? if($_POST['estado']==4) echo " selected" ;?>>Cerrada</option>
                 <option value="3"  class="fo"<? if($_POST['estado']==3) echo " selected" ;?>>Aprobada</option>
             </select></td>
           <td></td>
        <td colspan="2" style="text-align:right"><input type="submit" value="Filtrar" style="background-color:#006; color:#fff; font-size:12px; font-family:Tahoma, Geneva, sans-serif; margin-right:10px; width:90px; height:20px; border-radius:0.5em;"></td>
        </form>
    </tr>
    <tr id="titulo_reg"  style="background-color:rgb(0,0,255); color:rgb(255,255,255); font-family:Tahoma; font-size:12px;">
        <td width="20px" style="text-align:center;">#</td>
        <td width="120px"style="text-align:center;">Fecha OC</td>
        <td style="text-align:center;">Solicitante</td>
        <td style="text-align:center;">Concepto</td>
        <td style="text-align:center;">Centro Costos</td>
        <td style="text-align:center;">Total</td>
        <td style="text-align:center;">Estado</td>
        <td width="100px" style="text-align:center;">Fecha Entrega</td>
        <td width="20px" style="text-align:center;"></td>
        <td width="20px" style="text-align:center;"></td>
    </tr>
<?
 if(mysql_num_rows($res)!= NULL){
     $i=1;
 while($row = mysql_fetch_assoc($res)){
 
     
     switch($row['estado_oc']){
         case 1:
             $estado = "Abierto";
             break;
         case 2:
             $estado = "Pendiente";
             break;
         case 3: 
             $estado = "Cerrada";
             break;
         case 4: 
             $estado = "Aprobada";
             break;
     }
     
     switch($row['concepto']){
         case 1:
             $concepto = "Compra";
             break;
         case 2: 
             $concepto = "Mantenci&oacute;n";
             break;
         case 3:
             $concepto = "Reparaci&oacute;n";
             break;
     }
     
     
     
     ?>    
    <tr class="listado_datos" style="font-size:11px; font-family:Tahoma, Geneva, sans-serif; background-color:rgb(243,243,243); border-collapse:collapse;">
        <td style="border:1px solid #666;text-align:center; background-color:#F4F4F4;"><?=$i;$i++;?></td>
        <td style="border:1px solid #666;text-align:center; background-color:#F4F4F4;"><?=date("d-m-Y",strtotime($row['fecha_oc']));?></td>
        <td style="border:1px solid #666;text-align:center; background-color:#F4F4F4;"><?=$row['solicitante'];?></td>
        <td style="border:1px solid #666;text-align:center; background-color:#F4F4F4;"><?=$concepto;?></td>
        <td style="border:1px solid #666;text-align:center; background-color:#F4F4F4;"><? 
        
                $s="SELECT * FROM centros_costos WHERE Id_cc=".$row['centro_costos'];
                $r = mysql_query($s,$con);
                $ro = mysql_fetch_assoc($r);
                
                echo $ro['descripcion_cc'];
                
        
        
        
        ?></td>
        <td style="border:1px solid #666;text-align:center; background-color:#F4F4F4;"><?=$row['total'];?></td>
        <td style="border:1px solid #666;text-align:center; background-color:#F4F4F4;"><?=$estado;?></td>
        <td style="border:1px solid #666;text-align:center; background-color:#F4F4F4;"><?=date("d-m-Y",strtotime($row['fecha_entrega']));?></td>
        <td style="border:1px solid #666;text-align:center; background-color:#F4F4F4;"></td>
        <td style="border:1px solid #666;text-align:center; background-color:#F4F4F4;"></td>
 
    </tr>  
 <?    
 }
 }else{
     ?>
    <tr id="mensaje-sin-reg" style="color:rgb(255,255,255); font-family:Tahoma, Geneva, sans-serif;; font-size:12px;">
        <td colspan="100%">No existen OC a Ser Desplegadas</td>
    </tr>
 <?   
 }
?>
<form action="includes/Admin/OC_excel.php" method="POST">     
            <input type="hidden" name="sql" id="sql" hidden="hidden" value="<?  echo $sql; ?>">

            <table align="center">
            <tr><td>
           <input type="submit" value="Exportar a Excel"></td></tr>
            </table>
             </form>
</table>