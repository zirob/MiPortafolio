  
  
  <script>
  function calcular()
  {
	  c=0;
	  a=document.f1.cantidad.value;
	  b=document.f1.precio_pmp.value;
	  c=a*b;
	  document.f1.total.value=c;
  }
  </script>
    <style>
	.foo
	{
		border:1px solid #09F;
		background-color:#FFFFFF;
		color:#000066;
		font-size:11px;
		font-family:Tahoma, Geneva, sans-serif;
		width:80%;
		text-align:center;
	}
	
	</style>

<?php
$error=0;
	
//Validaciones
if(!empty($_POST['accion']))
{

	if(empty($_POST['codbar_productonew']))
	{
			$error=1;
			$mensaje=" Debe ingresar el codigo de barra  ";
	}

	
	if($error==0)
	{
		
			if(!empty($_GET['id_entrada']) )
			{
				$sql="SELECT  * FROM  productos_new_entradas WHERE id_entrada='".$_GET['id_entrada']."' and  rut_empresa='".$_SESSION['empresa']."'";
				$rec=mysql_query($sql);
				$row=mysql_fetch_array($rec);
				
				$cantidad=$_POST['cantidad']+$row['cantidad_anterior'];
				$precio  =($_POST['precio_pmp']*$_POST['cantidad'])+($row1['precio_pmp_anterior']*$row1['cantidad_anterior']);
				$precio  =round($precio/($_POST['cantidad']+$row1['cantidad_anterior']));
				$total   =round($precio*$cantidad);
				
				$sql= " UPDATE productos_new_entradas SET  ";
				$sql.=" factura='".$_POST['factura']."' ,";	
				$sql.=" cantidad='".$cantidad."' ,";
				$sql.=" precio_pmp='".$precio."' ,";
				$sql.=" total	='".$total."' ,";
				$sql.=" fecha_factura='".$_POST['fecha_factura']."' ,";	
				$sql.=" cantidad_anterior='".$row['cantidad_anterior']."' ,";	
				$sql.=" precio_pmp_anterior='".$row['precio_pmp_anterior']."' ,";	
				$sql.=" total_anterior='".$row['total_anterior']."' ";	
				$sql.=" WHERE id_entrada=".$_GET['id_entrada']." AND rut_empresa='".$_SESSION['empresa']."'";

				mysql_query($sql);
				$mensaje=" Actualización Correcta ";
				$mostrar=1;


				$sql_even = "INSERT INTO eventos (usuario, rut_empresa, tabla_evento, id_registro_tabla_evento, tipo_evento ";
	            $sql_even.= ", parametros_tipo_evento, ip_origen, observaciones, estado_evento, fecha_evento) ";
	            $sql_even.= "VALUES('".$_SESSION["user"]."', '".$_SESSION["empresa"]."', 'productos_new_entradas', '".$_GET['id_entrada']."', '3'";
	            $sql_even.= ", 'UPDATE:codbar_productonew,rut_empresa,factura,fecha_factura,cantidad
				,precio_pmp,total,cantidad_anterior,precio_pmp_anterior,total_anterior,usuario_ingreso,fecha_ingreso', '".$_SERVER['REMOTE_ADDR']."', 'Update de entrada productos', '1', '".date('Y-m-d H:i:s')."')";
	            mysql_query($sql_even, $con); 
			}
			else
			{
				$fecha=date("Y-m-d H:i:s");
				//maximo o anteior
				$sql="select max(id_entrada) from  productos_new_entradas ";
				$rec=mysql_query($sql);
				@$row=mysql_fetch_array($rec);
				
				$sql1="select *  from  productos_new_entradas  where id_entrada=".$row[0];
				$rec1=mysql_query($sql1);
				@$row1=mysql_fetch_array($rec1);
				@$num=mysql_num_rows($rec1);
								
				$cantidad=$_POST['cantidad']+$row1['cantidad'];
				$precio  =($_POST['precio_pmp']*$_POST['cantidad'])+($row1['precio_pmp']*$row1['cantidad']);
				$precio  =round($precio/($_POST['cantidad']+$row1['cantidad']));
				$total   =round($precio*$cantidad);
				
				//Valida si es la primera
				if(empty($num))
				{
					$row1=0;
				}
				
				$fecha=date("Y-m-d H:i:s");
				$sql=" INSERT INTO productos_new_entradas (codbar_productonew,rut_empresa,factura,fecha_factura,cantidad
				,precio_pmp,total,cantidad_anterior,precio_pmp_anterior,total_anterior,usuario_ingreso,fecha_ingreso) VALUES";
				$sql.=" ( ";
				$sql.=" '".$_POST['codbar_productonew']."', ";
				$sql.=" '".$_SESSION['empresa']."', ";
				$sql.=" '".$_POST['factura']."', ";
				$sql.=" '".$_POST['fecha_factura']."', ";
				$sql.=" '".$cantidad."', ";
				$sql.=" '".$precio."', ";
				$sql.=" '".$total."', ";
				$sql.=" '".$row1['cantidad']."', ";
				$sql.=" '".$row1['precio_pmp']."', ";
				$sql.=" '".$row1['total']."', ";
				$sql.=" '".$_SESSION['user']."', ";
				$sql.=" '".$fecha."' ";
				$sql.=" ) ";
				mysql_query($sql);
				$mensaje=" Inserciòn Correcta ";
				$mostrar=1;

				$consulta = "SELECT MAX(id_entrada) as id_entrada FROM productos_new_entradas WHERE rut_empresa='".$_SESSION["empresa"]."'";
	            $resultado=mysql_query($consulta);
	            $fila=mysql_fetch_array($resultado);
				$sql_even = "INSERT INTO eventos (usuario, rut_empresa, tabla_evento, id_registro_tabla_evento, tipo_evento ";
	            $sql_even.= ", parametros_tipo_evento, ip_origen, observaciones, estado_evento, fecha_evento) ";
	            $sql_even.= "VALUES('".$_SESSION["user"]."', '".$_SESSION["empresa"]."', 'productos_new_entradas', '".$fila['id_entrada']."', '2'";
	            $sql_even.= ", 'INSERT:codbar_productonew,rut_empresa,factura,fecha_factura,cantidad
				,precio_pmp,total,cantidad_anterior,precio_pmp_anterior,total_anterior,usuario_ingreso,fecha_ingreso', '".$_SERVER['REMOTE_ADDR']."', 'Insert de entrada productos', '1', '".date('Y-m-d H:i:s')."')";
	            mysql_query($sql_even, $con); 
			}
	}
	
	
}

//Rescato los Datos
if(!empty($_GET['id_entrada']) and (empty($_POST['primera'])))
{
	$sql="SELECT  * FROM  productos_new_entradas WHERE id_entrada='".$_GET['id_entrada']."' and  rut_empresa='".$_SESSION['empresa']."'";
	$rec=mysql_query($sql);
	$row=mysql_fetch_array($rec);
	$_POST=$row;
	$_POST['fecha_factura']=substr($_POST['fecha_factura'],0,10);	

} 


if($error==0)
{
	echo "<div style=' width:100%; height:auto; border-top: solid 3px blue;border-bottom: solid 3px blue;color:blue; text-align:center; font-family:tahoma; font-size:18px;'>";
	echo $mensaje;
	echo "</div>";
}
else
{
	echo "<div style=' width:100%; height:auto; border-top: solid 3px red ;border-bottom: solid 3px red; color:red; text-align:center;font-family:tahoma; font-size:18px;'>";
	echo $mensaje;
	echo "</div>";
}
?>
<form name='f1' id='f1' action="?cat=3&sec=35&id_entrada=<? echo $_GET['id_entrada']; ?>" method="POST">
<input  type="hidden" name="primera" value="1"/>

<table style="width:900px;" id="detalle-prov"  cellpadding="3" cellspacing="4" border="0">

<tr>
<td align="right" colspan="100%">
<a href='?cat=3&sec=33'><img src='img/view_previous.png' width='36px' height='36px' border='0' style='float:right;' class='toolTIP' title='Volver al Listado de Usuarios'></a>
</td>
</tr>
<?
if($mostrar==0)
{
?>

<tr height="30px">
</tr>
 
        <td><label>Producto</label><label style="color:red">(*)</label><br />
        <select name="codbar_productonew"  class="foo" onchange="submit()" 
        <?
			if(!empty($_GET['id_entrrada']))
			{
			 echo " disabled ";
			}
        ?>
        >
                <option value=""  class="foo">---</option>
            <?
                $s = "SELECT * FROM productos_new WHERE 1=1 ";
                $r = mysql_query($s,$con);
                
                while($roo = mysql_fetch_assoc($r)){
                    ?>  <option value="<?=$roo['codbar_productonew'];?>"   <? if($_POST['codbar_productonew']==$roo['codbar_productonew']) echo " selected" ;?> class="foo"><?=$roo['descripcion'];?></option> <?    
                }
        
                ?>
            </select>
        </td>
    </tr>
     <tr>
        <td><label>Factura:</label><br/><input size="10" class="foo" type="text" name="factura" value="<?=$_POST['factura'];?>"
        ></td>
       
        <td><label>Fecha Factura:</label><br/><input size="10" class="foo" type="date" name="fecha_factura" value="<?=$_POST['fecha_factura'];?>"></td>
    </tr>
         <tr>
        <td><label>Cantidad:</label><br/><input size="10" onchange="calcular()" class="foo" type="text" name="cantidad" value="<?=$_POST['cantidad'];?>"
        ></td> 
       
        <td><label>Precio pmp	:</label><br/><input onchange="calcular()" size="10" class="foo" type="text" name="precio_pmp" value="<?=$_POST['precio_pmp'];?>"></td>
        <td><label>Total:</label><br/><input size="10"   readonly="readonly"  class="foo" type="text" name="total" value="<?=$_POST['total'];?>"></td>
    </tr>
        <tr>
       <td style="text-align: right;"  colspan="100%"><input name="accion" type="submit" value="Grabar"  style="background-color:#006; color:#fff; font-size:12px; font-family:Tahoma, Geneva, sans-serif; margin-right:5px; width:100px; height:25px; border-radius:0.5em;"></td>
   <tr>
			<td colspan="100%" style='text-align:Center;text-align:center;font-family:tahoma;;color:red;font-size:15px;font-weight:bold;' >
				(*) Campos de Ingreso Obligatorio.
			</td>
	</tr>
</table>

<?
	}
?>
</table>
</form>