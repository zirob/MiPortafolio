<?php

//Consulta que contiene el sql
$msg="";
$error="";

$sql ="SELECT s.*,c.descripcion_cc  FROM salida_petroleo s,centros_costos c
WHERE  s.rut_empresa='".$_SESSION['empresa']."'  and c.Id_cc=s.centro_costo ";

if(empty($_POST['recarga']))
{
  $fecha=date('d-m-Y');
  $dia=substr($fecha,0,2);
  $mes=substr($fecha,3,2);
  $ano=substr($fecha,6,4);
  $_POST['mes']=$mes;
  $_POST['agno']=$ano;;
}

//Filtros
if(!empty($_POST['dia']))
$sql.=" AND s.dia like'%".$_POST['dia']."%' ";

if(!empty($_POST['mes']))
$sql.=" AND s.mes like'%".$_POST['mes']."%' ";

if(!empty($_POST['agno']))
$sql.=" AND s.agno like'%".$_POST['agno']."%' ";


if(!empty($_POST['tipo_salida']))
$sql.=" AND s.tipo_salida like'%".$_POST['tipo_salida']."%' ";

/*
if(!empty($_POST['patente']))
$sql.=" AND de.patente like'%".$_POST['patente']."%' ";
*/

if(!empty($_POST['litros']))
$sql.=" AND s.litros like'%".$_POST['litros']."%' ";

if(!empty($_POST['descripcion_cc']))
$sql.=" AND c.descripcion_cc like'%".$_POST['descripcion_cc']."%' ";

$sql.=" AND 1=1  order by s.dia,s.mes,s.agno asc";




//Efectua la Consulta
$res = mysql_query($sql,$con);
$num = mysql_num_rows($res); 
?>
    <style>
	.fo
	{
		border:1px solid #09F;
		background-color:#FFFFFF;
		color:#000066;
		font-size:11px;
		font-family:Tahoma, Geneva, sans-serif;
		width:80%;
		text-align:center;
	}
	
	</style>
    <br /><br />
    <form action="?cat=4&sec=3&filtro=1" method="POST">
    <input type='hidden' name='recarga' value='1'>
    <table width="95%">
      
    </table>
<table id="list_registros" style=" border-collapse:collapse" border="1" >

    <tr  style='font-family:tahoma;font-size:12px;'>
        <td style="text-align:left; font-weight:bold; ">Filtro:</td>
        <td style="text-align:center"><input name='dia' value='<? echo $_POST['dia']?>' class="fo" style="width:50px;"></td>
        <td style="text-align:center">
        <select name='mes' class="fo">
        <option value='0'></option>
        <option value='1' <? if($_POST['mes']==1)  echo " selected" ;?> >Enero</option>
        <option value='2' <? if($_POST['mes']==2)  echo " selected" ;?> >Febrero</option>
        <option value='3' <? if($_POST['mes']==3)  echo " selected" ;?> >Marzo</option>
        <option value='4' <? if($_POST['mes']==4)  echo " selected" ;?> >Abril</option>
        <option value='5' <? if($_POST['mes']==5)  echo " selected" ;?> >Mayo</option>
        <option value='6' <? if($_POST['mes']==6)  echo " selected" ;?> >Junio</option>
        <option value='7' <? if($_POST['mes']==7)  echo " selected" ;?> >Julio</option>
        <option value='8' <? if($_POST['mes']==8)  echo " selected" ;?> >Agosto</option>
        <option value='9' <? if($_POST['mes']==9)  echo " selected" ;?> >Septiembre</option>
        <option value='10' <? if($_POST['mes']==10)  echo " selected" ;?> >Octubre</option>
        <option value='11' <? if($_POST['mes']==11)  echo " selected" ;?> >Noviembre</option>
        <option value='12' <? if($_POST['mes']==12)  echo " selected" ;?> >Diciembre</option>
        </select>                
        </td>
        <td style="text-align:center">  
        <input name='agno'  value='<? echo $_POST['agno'] ?>'  class='fo'/>
        </td>
         <td style="text-align:center">
        <select name='tipo_salida' class="fo">
        <option value='0'></option>
        <option value='1' <? if($_POST['tipo_salida']==1)  echo " selected" ;?> >Activo</option>
        <option value='2' <? if($_POST['tipo_salida']==2)  echo " selected" ;?> >Lugares Fisicos</option>
        </td>
        <td style="text-align:center"><input name='litros' value='<? echo $_POST['litros']?>' class="fo" style="width:150px;">
        </td>
        <td style="text-align:center">
                  <select name="descripcion_cc"  class="fo">
                <option value=""  class="fo">---</option>
            <?
                $s = "SELECT * FROM centros_costos ORDER BY descripcion_cc";
                $r = mysql_query($s,$con);
                
                while($roo = mysql_fetch_assoc($r)){
                    ?>  <option value="<?=$roo['descripcion_cc'];?>"   <? if($_POST['descripcion_cc']==$roo['descripcion_cc']) echo " selected" ;?> class="fo"><?=$roo['descripcion_cc'];?></option> <?    
                }
        
                ?>
            </select>
        </td>
    	 <td style="text-align:center"><input type="Submit" value="Filtrar" style="background-color:#006; color:#fff; font-size:12px; font-family:Tahoma, Geneva, sans-serif; margin-right:5px; width:100px; height:25px; border-radius:0.5em;"></td>
    </tr>
    <tr  style="background-color:rgb(0,0,255); color:rgb(255,255,255); font-family:Tahoma; font-size:12px;">
        <td style="text-align:center; ">#</td>
        <td style="text-align:center">Dia</td>
        <td style="text-align:center">Mes</td>
        <td style="text-align:center">A&ntilde;o</td>
        <td style="text-align:center">Tipo Salida</td>
        <td style="text-align:center">Litros</td>
        <td style="text-align:center">Centro C.</td>
       <td></td>
        <!--<td width="100px">Editar</td> -->
    </tr>    

<?
/*
if(mysql_num_rows($res)!=NULL){
    $i=1;
while($row = mysql_fetch_assoc($res)){
    
    
           switch($row['tipo_producto']){
                    case 1:  $tipo="Maquinarias y Equipos"; break;
                    case 2:  $tipo="Vehiculo Menor"; break;
                    case 3:  $tipo="Herramientas"; break;
                    case 4:  $tipo="Muebles"; break;
                    case 5:  $tipo="Generador"; break;
                    case 6:  $tipo="Plantas"; break;
                    case 7:  $tipo="Equipos de Tunel"; break;
                    case 8:  $tipo="Otros"; break;
               }*/
?>
<?
	//Desempilamos los datos
	$i=1;
    if($num>0)
    {
    	while($row=mysql_fetch_array($res))
    	{
    	if($row['tipo_salida']==1) $row['tipo_salida']="Acitvo";
    	if($row['tipo_salida']==2) $row['tipo_salida']="Lugares Fisicos";
        echo "<tr   style='font-family:tahoma;font-size:12px;'>";
        echo "    <td style='text-align:center'>".$i++."</td>";
        echo "    <td style='text-align:center'>".$row['dia']."</td>";
        echo "    <td style='text-align:center'>".$row['mes']."</td>";
        echo "    <td style='text-align:center'>".$row['agno']."</td>";
    	echo "    <td style='text-align:center'>".$row['tipo_salida']."</td>";
        echo "    <td style='text-align:center' >".$row['litros']."</td>";
        echo "    <td style='text-align:center'>".$row['descripcion_cc']."</td>"; 
    	echo "    <td style='text-align: center;'>
    				    
    				</td>";
        echo "</tr>";
    	}
    }
    else
    {
        echo "<tr id='mensaje-sin-reg' style='color:rgb(255,255,255); font-family:Tahoma, Geneva, sans-serif; font-size:12px;'>";
        echo "<td colspan='100%'>No existen Bodegas a Ser Desplegadas</td>";
        echo "</ tr>";
    }
 ?>


</table>
</form>
<form action="includes/Admin/petroleo_excel.php" method="POST">     
            <input type="hidden" name="sql" id="sql" hidden="hidden" value="<?  echo $sql; ?>">

            <table align="center">
            <tr><td>
           <input type="submit" value="Exportar a Excel"></td></tr>
            </table>
             </form>