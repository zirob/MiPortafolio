<script type="text/javascript">
function ValidaSoloNumeros() {
   if ((event.keyCode < 48) || (event.keyCode > 57)) 
      event.returnValue = false;
}
</script>

<?php

if(empty($_POST["filtrar"])){
    $_POST['anio'] = date("Y");
    $_POST['mes'] = date("m");
}

$sql ="SELECT * FROM petroleo WHERE rut_empresa='".$_SESSION['empresa']."'";

if(isset($_POST['mes']) && $_POST['mes']!="" )
{
    if($_POST['mes']==13)  $MesEsp = $_POST['mes'] - 5;//Agosto
    if($_POST['mes']==14) $MesEsp = $_POST['mes'] - 5;//Septiembre
    if(!empty($MesEsp)){
        $sql.=" and mes like '%".$MesEsp."%'"; 
    }else{
        $sql.=" and mes like'%".$_POST['mes']."%'"; 
    }
}else{
   $sql.=" and mes like '%".date('m')."%'";
}

if(isset($_POST['anio']) && $_POST['anio']!=""){
   $sql.=" and agno like'%".$_POST['anio']."%'"; 
}else{
   $sql.=" and agno='".date('Y')."'";
}

$sql.="  ORDER BY agno,mes,dia";

// var_dump($_POST);



if(isset($error) && !empty($error)){
    ?>
    <div id="main-error"><? echo $error;?></div>
    <?
}elseif($msg){
    ?>
    <div id="main-ok"><? echo $msg;?></div>
    <?
}
// echo "<br>mes =".$_POST['mes'];
?>


</style>

<table id="list_registros" >
  
</table>

<style>
.fo
{
  border:1px solid #09F;
  background-color:#FFFFFF;
  color:#000066;
  font-size:11px;
  font-family:Tahoma, Geneva, sans-serif;
  width:40%;
  text-align:center;
}
</style>

<table id="list_registros" border="1" style="border-collapse:collapse;" >
    <form action="?cat=4&sec=5" method="POST">
        <tr id="titulo_reg" style="background-color: #fff;">
            <td colspan="2" style="font-family:Tahoma; font-size:12px;text-align:center;"><label>Filtro:</label></td>
            <td colspan="2" style="font-family:Tahoma; font-size:12px;text-align:center;"><label>Mes:&nbsp;&nbsp;</label>
                <!-- <input type="text" size="2" name="mes" class="fo"> -->
                <select name="mes" <? if($estado==3){ echo "Disabled"; }?> class='fo' >
                    <option value="0" <? if($_POST['mes']==0) echo " selected "; ?> >---</option>  
                    <option value="01" <? if($_POST['mes']==01){ echo " selected ";} ?> >Enero</option>
                    <option value="02" <? if($_POST['mes']==02){ echo " selected ";} ?> >Febrero</option>
                    <option value="03" <? if($_POST['mes']==03){ echo " selected ";} ?> >Marzo</option>
                    <option value="04" <? if($_POST['mes']==04){ echo " selected ";} ?> >Abril</option>
                    <option value="05" <? if($_POST['mes']==05){ echo " selected ";} ?> >Mayo</option>
                    <option value="06" <? if($_POST['mes']==06){ echo " selected ";} ?> >Junio</option>
                    <option value="07" <? if($_POST['mes']==07){ echo " selected ";} ?> >Julio</option>

                    <option value="13" <?  if($_POST['mes'] == 13){ echo " selected ";} ?> >Agosto</option>
                    <option value="14" <? if($_POST['mes']==14){ echo " selected ";} ?> >Septiembre</option>

                    <option value="10" <? if($_POST['mes']==10){ echo " selected ";} ?> >Octubre</option>
                    <option value="11" <? if($_POST['mes']==11){ echo " selected ";} ?> >Noviembre</option>
                    <option value="12" <? if($_POST['mes']==12){ echo " selected ";} ?> >Diciembre</option>
                </select>
            </td>

            <td colspan="2" style="font-family:Tahoma; font-size:12px;text-align:center;"><label>A&ntilde;o:&nbsp;&nbsp;</label>
                <input type="text" size="2" name="anio" value='<?=$_POST["anio"];?>' class="fo" onKeyPress="ValidaSoloNumeros()">
            </td>
            <td></td>
            <td colspan="2" style="font-family:Tahoma; font-size:12px; text-align:right;">
                <input type="submit" value="Filtrar" style="background-color:#006; color:#fff; font-size:12px; font-family:Tahoma, Geneva, sans-serif; margin-right:10px; width:90px; height:20px; border-radius:0.5em;"><input type='hidden' name='filtrar' value='filtrar' >
            </td>

        </tr>
    </form>

    <tr id="titulo_reg" style="background-color:rgb(0,0,255); color:rgb(255,255,255); font-family:Tahoma; font-size:12px;">
        <td  style="text-align:center;">#</td>
        <td  style="text-align:center;">Dia</td>
        <td  style="text-align:center;">N° Factura</td>
        <td  style="text-align:center;">Litros</td>
        <td  style="text-align:center;">Valor IEF.</td>
        <td  style="text-align:center;">Valor IEV.</td>
        <td  style="text-align:center;">Total IEF.</td>
        <td width="60px"  style="text-align:center;"></td>
        <td width="60px"  style="text-align:center;"></td>
    </tr>    

    <?
	$res = mysql_query($sql,$con);
    if(mysql_num_rows($res)!=null){
        $i=1;
        while($row = mysql_fetch_assoc($res)){
            ?>
            <tr  style="font-size:11px; font-family:Tahoma, Geneva, sans-serif; background-color:rgb(243,243,243);" id="row">
                <td style="text-align: center;"><?echo $i;$i++;?></td>
                <td style="text-align: center;"><?=$row['dia'];?></td>
                <td style="text-align: center;"><?=$row['num_factura']; ?></td>
                <td style="text-align: center;"><?=number_format($row['litros'],0,'','.'); ?></td>
                <td style="text-align: right;"><?=number_format($row['valor_IEF'],0,'','.'); ?></td>
                <td style="text-align: right;"><?=number_format($row['valor_IEV'],0,'','.'); ?></td>
                <td style="text-align: right;"><?=number_format($row['total_IEF'],0,'','.'); ?></td>
                <td style="text-align: center;"></td>
                <td style="text-align: center;"></td>
            </tr>


            <?php 
        }

    }else{
        ?>
        <tr  id="mensaje-sin-reg" style="color:rgb(255,255,255); font-family:Tahoma, Geneva, sans-serif; ; font-size:12px;">
            <td colspan="9">No existen Facturas de Petroleo para ser Desplegadas</td>
        </tr>
        <? 
    }
    ?>
</table>
<form action="includes/Admin/petroleo_entrada_excel.php" method="POST">     
            <input type="hidden" name="sql" id="sql" hidden="hidden" value="<?  echo $sql; ?>">

            <table align="center">
            <tr><td>
           <input type="submit" value="Exportar a Excel"></td></tr>
            </table>
             </form>

