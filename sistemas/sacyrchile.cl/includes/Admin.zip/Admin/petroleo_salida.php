<?php
//AL PRINCIPIO COMPRUEBO SI HICIERON CLICK EN ALGUNA PÁGINA
if(isset($_GET['page'])){
    $page= $_GET['page'];
}else{
//SI NO DIGO Q ES LA PRIMERA PÁGINA
    $page=1;
}

//ACA SE SELECCIONAN TODOS LOS DATOS DE LA TABLA
$consulta = "SELECT s.*,c.descripcion_cc  FROM salida_petroleo s,centros_costos c
WHERE  s.rut_empresa='".$_SESSION['empresa']."'  and c.Id_cc=s.centro_costo ";
$datos=mysql_query($consulta,$con);

//MIRO CUANTOS DATOS FUERON DEVUELTOS
$num_rows=mysql_num_rows($datos);

//ACA SE DECIDE CUANTOS RESULTADOS MOSTRAR POR PÁGINA , EN EL EJEMPLO PONGO 15
$rows_per_page= 20;

//CALCULO LA ULTIMA PÁGINA
$lastpage= ceil($num_rows / $rows_per_page);

//COMPRUEBO QUE EL VALOR DE LA PÁGINA SEA CORRECTO Y SI ES LA ULTIMA PÁGINA
$page=(int)$page;
if($page > $lastpage){
    $page= $lastpage;
}
if($page < 1){
    $page=1;
}

//CREO LA SENTENCIA LIMIT PARA AÑADIR A LA CONSULTA QUE DEFINITIVA
$limit= 'LIMIT '. ($page -1) * $rows_per_page . ',' .$rows_per_page;

//Consulta que contiene el sql
$msg="";
$error="";

$sql ="SELECT s.*,c.descripcion_cc  FROM salida_petroleo s,centros_costos c
WHERE  s.rut_empresa='".$_SESSION['empresa']."'  and c.Id_cc=s.centro_costo ";



//Filtros
if(!empty($_POST['dia']))
$sql.=" AND s.dia like'%".$_POST['dia']."%' ";

if(!empty($_POST['mes']))
$sql.=" AND s.mes like'%".$_POST['mes']."%' ";

if(!empty($_POST['agno']))
$sql.=" AND s.agno like'%".$_POST['agno']."%' ";


if(!empty($_POST['tipo_salida']))
$sql.=" AND s.tipo_salida like'%".$_POST['tipo_salida']."%' ";

/*
if(!empty($_POST['patente']))
$sql.=" AND de.patente like'%".$_POST['patente']."%' ";
*/

if(!empty($_POST['litros']))
$sql.=" AND s.litros like'%".$_POST['litros']."%' ";

if(!empty($_POST['descripcion_cc']))
$sql.=" AND c.descripcion_cc like'%".$_POST['descripcion_cc']."%' ";

$sql.=" AND 1=1 ";
$sql.= " ".$limit;




//Efectua la Consulta
$res = mysql_query($sql,$con);
?>
    <style>
	.fo
	{
		border:1px solid #09F;
		background-color:#FFFFFF;
		color:#000066;
		font-size:11px;
		font-family:Tahoma, Geneva, sans-serif;
		width:80%;
		text-align:center;
	}
	
    /* -------------------------------------------- */
/* ----------- Pagination: Digg Style --------- */
/* -------------------------------------------- */
ul    { border:0; margin:0; padding:0; }
#pagination-digg li          { border:0; margin:0; padding:0; font-size:11px; list-style:none; /* savers */ float:left; }
#pagination-digg a           { border:solid 1px #9aafe5; margin-right:2px; }
#pagination-digg .previous-off,
#pagination-digg .next-off   { border:solid 1px #DEDEDE; color:#888888; display:block; float:left; font-weight:bold; margin-right:2px; padding:3px 4px; }
#pagination-digg .next a,
#pagination-digg .previous a { font-weight:bold; }
#pagination-digg .active     { background:#2e6ab1; color:#FFFFFF; font-weight:bold; display:block; float:left; padding:4px 6px; /* savers */ margin-right:2px; }
#pagination-digg a:link,
#pagination-digg a:visited   { color:#0e509e; display:block; float:left; padding:3px 6px; text-decoration:none; }
#pagination-digg a:hover     { border:solid 1px #0e509e; }
	</style>
    <br /><br />
    <form action="?cat=3&sec=11&filtro=1" method="POST">
    <table width="95%">
        <tr>
        <td id="list_link"  colspan="100%"><a href="?cat=3&sec=12"><img src="img/add1.png" width="36px" height="36px" border="0" class="toolTIP" title="Agregar Bodega"></a></td>
    
    </tr>
    </table>
<table id="list_registros" style=" border-collapse:collapse" border="1" >

    <tr  style='font-family:tahoma;font-size:12px;'>
        <td style="text-align:left; font-weight:bold; ">Filtro:</td>
        <td style="text-align:center"><input name='dia' value='<? echo $_POST['dia']?>' class="fo" style="width:50px;"></td>
        <td style="text-align:center">
        <select name='mes' class="fo">
        <option value='0'></option>
        <option value='1' <? if($_POST['mes']==1)  echo " selected" ;?> >Enero</option>
        <option value='2' <? if($_POST['mes']==2)  echo " selected" ;?> >Febrero</option>
        <option value='3' <? if($_POST['mes']==3)  echo " selected" ;?> >Marzo</option>
        <option value='4' <? if($_POST['mes']==4)  echo " selected" ;?> >Abril</option>
        <option value='5' <? if($_POST['mes']==5)  echo " selected" ;?> >Mayo</option>
        <option value='6' <? if($_POST['mes']==6)  echo " selected" ;?> >Junio</option>
        <option value='7' <? if($_POST['mes']==7)  echo " selected" ;?> >Julio</option>
        <option value='8' <? if($_POST['mes']==8)  echo " selected" ;?> >Agosto</option>
        <option value='9' <? if($_POST['mes']==9)  echo " selected" ;?> >Septiembre</option>
        <option value='10' <? if($_POST['mes']==10)  echo " selected" ;?> >Octubre</option>
        <option value='11' <? if($_POST['mes']==11)  echo " selected" ;?> >Noviembre</option>
        <option value='12' <? if($_POST['mes']==12)  echo " selected" ;?> >Diciembre</option>
        </select>                
        </td>
        <td style="text-align:center">
        <select name='agno' class="fo">
        <option value='0'></option>
        <option value='2012' <? if($_POST['agno']==2012)  echo " selected" ;?> >2012</option>
        <option value='2013' <? if($_POST['agno']==2013)  echo " selected" ;?> >2013</option>
        <option value='2014' <? if($_POST['agno']==2014)  echo " selected" ;?> >2014</option>
        <option value='2015' <? if($_POST['agno']==2015)  echo " selected" ;?> >2015</option>
        </td>
         <td style="text-align:center">
        <select name='tipo_salida' class="fo">
        <option value='0'></option>
        <option value='1' <? if($_POST['tipo_salida']==1)  echo " selected" ;?> >Activo</option>
        <option value='2' <? if($_POST['tipo_salida']==2)  echo " selected" ;?> >Lugares Fisicos</option>
        </td>
        <td style="text-align:center"><input name='descripcion' value='<? echo $_POST['descripcion']?>' class="fo" style="width:150px;">
        </td>
        <td style="text-align:center"><input name='descripcion_cc' value='<? echo $_POST['descripcion_cc']?>' class="fo" style="width:150px;"></td>
    	<td></td>
         <td style="text-align:center"><input type="Submit" value="Filtrar" style="background-color:#006; color:#fff; font-size:12px; font-family:Tahoma, Geneva, sans-serif; margin-right:5px; width:100px; height:25px; border-radius:0.5em;"></td>
    </tr>
    <tr  style="background-color:rgb(0,0,255); color:rgb(255,255,255); font-family:Tahoma; font-size:12px;">
        <td style="text-align:center; ">#</td>
        <td style="text-align:center">Dia</td>
        <td style="text-align:center">Mes</td>
        <td style="text-align:center">A&ntilde;o</td>
        <td style="text-align:center">Tipo Salida</td>
        <td style="text-align:center">Litros</td>
        <td style="text-align:center">Centro C.</td>
       <td></td>
       <td></td>
        <!--<td width="100px">Editar</td> -->
    </tr>    

<?
/*
if(mysql_num_rows($res)!=NULL){
    $i=1;
while($row = mysql_fetch_assoc($res)){
    
    
           switch($row['tipo_producto']){
                    case 1:  $tipo="Maquinarias y Equipos"; break;
                    case 2:  $tipo="Vehiculo Menor"; break;
                    case 3:  $tipo="Herramientas"; break;
                    case 4:  $tipo="Muebles"; break;
                    case 5:  $tipo="Generador"; break;
                    case 6:  $tipo="Plantas"; break;
                    case 7:  $tipo="Equipos de Tunel"; break;
                    case 8:  $tipo="Otros"; break;
               }*/
?>
<?
	//Desempilamos los datos
	$i=1;
	while($row=mysql_fetch_array($res))
	{
	if($row['tipo_salida']==1) $row['tipo_salida']="Acitvo";
	if($row['tipo_salida']==2) $row['tipo_salida']="Lugares Fisicos";
    echo "<tr   style='font-family:tahoma;font-size:12px;'>";
    echo "    <td style='text-align:center'>".$i++."</td>";
    echo "    <td style='text-align:center'>".$row['dia']."</td>";
    echo "    <td style='text-align:center'>".$row['mes']."</td>";
    echo "    <td style='text-align:center'>".$row['agno']."</td>";
	echo "    <td style='text-align:center'>".$row['tipo_salida']."</td>";
    echo "    <td style='text-align:center' >".$row['litros']."</td>";
    echo "    <td style='text-align:center'>".$row['descripcion_cc']."</td>"; 
	echo "    <td style='text-align: center;'>
				    <a href='?cat=3&sec=12&action=2&id_salida_petroleo=".$row['id_salida_petroleo']."' >
					    <img src='img/edit.png' width='24px' height='24px' border='0' class='toolTIP' title='Editar Salida de Petroleo'>
					</a>
				</td>";
	echo "    <td style='text-align: center;'>
				    <a href='?cat=3&sec=16&action=2&id_salida_petroleo=".$row['id_salida_petroleo']."' >
					    <img src='img/view.png' width='24px' height='24px' border='0' class='toolTIP' title='Ver Salida de Petroleo '>
					</a>
				</td>";
    echo "</tr>";
	}
 ?>


</table>
</form>
<table width="900px" align="center" border="0" >
<tr>
    <td>
<?

//UNA VEZ Q MUESTRO LOS DATOS TENGO Q MOSTRAR EL BLOQUE DE PAGINACIÓN SIEMPRE Y CUANDO HAYA MÁS DE UNA PÁGINA
if($num_rows != 0){
   $nextpage= $page +1;
   $prevpage= $page -1;

?><ul id="pagination-digg"><?
//SI ES LA PRIMERA PÁGINA DESHABILITO EL BOTON DE PREVIOUS, MUESTRO EL 1 COMO ACTIVO Y MUESTRO EL RESTO DE PÁGINAS
 if ($page == 1) {
    ?>
      <li class="previous-off">&laquo; Previous</li>
      <li class="active">1</li> <?
    for($i= $page+1; $i<= $lastpage ; $i++){?>
            <li><a href="?&cat=3&sec=14&page=<? echo $i;?>"><? echo $i;?></a></li>
 <? } 

 //Y SI LA ULTIMA PÁGINA ES MAYOR QUE LA ACTUAL MUESTRO EL BOTON NEXT O LO DESHABILITO
    if($lastpage >$page ){?>       
      <li class="next"><a href="?&cat=3&sec=14&page=<? echo $nextpage;?>" >Next &raquo;</a></li><?
    }else{?>
      <li class="next-off">Next &raquo;</li>
<?  }
} else {
    //EN CAMBIO SI NO ESTAMOS EN LA PÁGINA UNO HABILITO EL BOTON DE PREVIUS Y MUESTRO LAS DEMÁS
    ?>
      <li class="previous"><a href="?&cat=3&sec=14&page=<? echo $prevpage;?>"  >&laquo; Previous</a></li><?
      for($i= 1; $i<= $lastpage ; $i++){
            //COMPRUEBO SI ES LA PÁGINA ACTIVA O NO
            if($page == $i){
        ?>  <li class="active"><? echo $i;?></li><?
            }else{
        ?>  <li><a href="?&cat=3&sec=14&page=<? echo $i;?>" ><? echo $i;?></a></li><?
            }
      }
         //SI NO ES LA ÚLTIMA PÁGINA ACTIVO EL BOTON NEXT    
      if($lastpage >$page ){    ?> 
      <li class="next"><a href="?&cat=3&sec=14&page=<? echo $nextpage;?>">Next &raquo;</a></li><?
      }else{
    ?> <li class="next-off">Next &raquo;</li><?
      }
 }   
?></ul></div><?
}
?>
 </td>
</tr>

</table>