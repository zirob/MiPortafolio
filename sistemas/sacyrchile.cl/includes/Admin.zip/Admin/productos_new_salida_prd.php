  
  
  <script>
  function calcular()
  {
	  c=0;
	  a=document.f1.cantidad.value;
	  b=document.f1.precio_pmp.value;
	  c=a*b;
	  document.f1.total.value=c;
  }
  </script>
    <style>
	.foo
	{
		border:1px solid #09F;
		background-color:#FFFFFF;
		color:#000066;
		font-size:11px;
		font-family:Tahoma, Geneva, sans-serif;
		width:80%;
		text-align:center;
	}
	
	</style>

<?php
$error=0;
	
//Validaciones
if(!empty($_POST['accion']))
{

	if(empty($_POST['codbar_productonew']))
	{
			$error=1;
			$mensaje=" Debe ingresar el codigo el producto  ";
	}

	
	if($error==0)
	{
		
			if(!empty($_GET['id_salida']) )
			{
				
				$sql= " UPDATE productos_new_salidas SET  ";
				$sql.=" codbar_productonew='".$_POST['codbar_productonew']."' ,";	
				$sql.=" rut_empresa='".$_SESSION['empresa']."' ,";
				$sql.=" fecha_salida='".$_POST['fecha_salida']."' ,";
				$sql.=" cantidad	='".$_POST['cantidad']."' ,";
				$sql.=" precio_pmp='".$_POST['precio_pmp']."' ,";	
				$sql.=" total='".$_POST['total']."' ,";	
				$sql.=" persona_solicita='".$_SESSION['user']."' ,";	
				$sql.=" cod_bodega='".$_POST['cod_bodega']."', ";	
				$sql.=" id_cc='".$_POST['id_cc']."', ";	
				$sql.=" id_lf='".$_POST['id_lf']."', ";	
				$sql.=" id_ot='".$_POST['id_ot']."' ,";	
				$sql.=" cod_detalle_producto='".$_POST['cod_detalle_producto']."', ";	
				$sql.=" cod_producto='".$_POST['cod_producto']."', ";	
				$sql.=" observaciones='".$_POST['observaciones']."' ";	
				$sql.=" WHERE id_salida=".$_GET['id_salida']." AND rut_empresa='".$_SESSION['empresa']."'";
				mysql_query($sql);
				$mensaje=" Actualización Correcta ";
				$mostrar=1;


				$sql_even = "INSERT INTO eventos (usuario, rut_empresa, tabla_evento, id_registro_tabla_evento, tipo_evento ";
	            $sql_even.= ", parametros_tipo_evento, ip_origen, observaciones, estado_evento, fecha_evento) ";
	            $sql_even.= "VALUES('".$_SESSION["user"]."', '".$_SESSION["empresa"]."', 'productos_new_salidas', '".$_GET['id_salida']."', '3'";
	            $sql_even.= ", 'UPDATE:codbar_productonew,rut_empresa,fecha_salida,cantidad
				,precio_pmp,total,persona_solicita,cod_bodega,id_cc,id_lf,id_ot,cod_detalle_producto,cod_producto,usuario_ingreso,fecha_ingreso,estado_salida,observaciones', '".$_SERVER['REMOTE_ADDR']."', 'Update de entrada productos', '1', '".date('Y-m-d H:i:s')."')";
	            mysql_query($sql_even, $con); 
				
			}
			else
			{
		
				$fecha=date("Y-m-d H:i:s");
				
				
				$fecha=date("Y-m-d H:i:s");
				$sql=" INSERT INTO productos_new_salidas (codbar_productonew,rut_empresa,fecha_salida,cantidad
				,precio_pmp,total,persona_solicita,cod_bodega,id_cc,id_lf,id_ot,cod_detalle_producto,cod_producto,usuario_ingreso,fecha_ingreso,estado_salida,observaciones) VALUES";
				$sql.="  ( ";
				$sql.=" '".$_POST['codbar_productonew']."', ";
				$sql.=" '".$_SESSION['empresa']."', ";
				$sql.=" '".$_POST['fecha_salida']."', ";
				$sql.=" '".$_POST['cantidad']."', ";
				$sql.=" '".$_POST['precio_pmp']."', ";
				$sql.=" '".$_POST['total']."', ";
				$sql.=" '".$_SESSION['user']."', ";
				$sql.=" '".$_POST['cod_bodega']."', ";
				$sql.=" '".$_POST['id_cc']."', ";
				$sql.=" '".$_POST['id_lf']."', ";
				$sql.=" '".$_POST['id_ot']."', ";
				$sql.=" '".$_POST['cod_detalle_producto']."', ";
				$sql.=" '".$_POST['cod_producto']."', ";
				$sql.=" '".$_SESSION['user']."', ";
				$sql.=" '".$fecha."', ";
				$sql.=" 1, ";
				$sql.=" '".$_POST['observaciones']."' ) ";
				mysql_query($sql);
				$mensaje=" Inserciòn Correcta ";
				$mostrar=1;

				$consulta = "SELECT MAX(id_salida) as id_salida FROM productos_new_salidas WHERE rut_empresa='".$_SESSION["empresa"]."'";
	            $resultado=mysql_query($consulta);
	            $fila=mysql_fetch_array($resultado);
				$sql_even = "INSERT INTO eventos (usuario, rut_empresa, tabla_evento, id_registro_tabla_evento, tipo_evento ";
	            $sql_even.= ", parametros_tipo_evento, ip_origen, observaciones, estado_evento, fecha_evento) ";
	            $sql_even.= "VALUES('".$_SESSION["user"]."', '".$_SESSION["empresa"]."', 'productos_new_salidas', '".$fila['id_salida']."', '2'";
	            $sql_even.= ", 'INSERT:codbar_productonew,rut_empresa,fecha_salida,cantidad
				,precio_pmp,total,persona_solicita,cod_bodega,id_cc,id_lf,id_ot,cod_detalle_producto,cod_producto,usuario_ingreso,fecha_ingreso,estado_salida,observaciones', '".$_SERVER['REMOTE_ADDR']."', 'Insert de entrada productos', '1', '".date('Y-m-d H:i:s')."')";
	            mysql_query($sql_even, $con); 
			}
	}
	
	
}

//Triago el pm
if(($_POST['codbar_productonew']))
{
	$sql="SELECT  * FROM  productos_new WHERE codbar_productonew='".$_POST['codbar_productonew']."' and  rut_empresa='".$_SESSION['empresa']."'";
	$rec=mysql_query($sql);
	$row=mysql_fetch_array($rec);
	$_POST['precio_pmp']=$row['precio_pmp'];
}

//Rescato los Datos
if(!empty($_GET['id_salida']) and (empty($_POST['primera'])))
{
	$sql="SELECT  * FROM  productos_new_salidas WHERE id_salida='".$_GET['id_salida']."' and  rut_empresa='".$_SESSION['empresa']."'";
	$rec=mysql_query($sql);
	$row=mysql_fetch_array($rec);
	$_POST=$row;
	$_POST['fecha_salida']=substr($_POST['fecha_salida'],0,10);	
	
	if(!empty($_POST['cod_bodega']))
	$_POST['tipo_salida1']=1;
	
	if(!empty($_POST['id_cc']))
	$_POST['tipo_salida1']=2;
	
	if(!empty($_POST['cod_producto']))
	$_POST['tipo_salida2']=1;
	
	if(!empty($_POST['id_lf']))
	$_POST['tipo_salida2']=2;
	
	if(!empty($_POST['id_ot']))
	$_POST['tipo_salida2']=3;
	

} 


if($error==0)
{
	echo "<div style=' width:100%; height:auto; border-top: solid 3px blue;border-bottom: solid 3px blue;color:blue; text-align:center; font-family:tahoma; font-size:18px;'>";
	echo $mensaje;
	echo "</div>";
}
else
{
	echo "<div style=' width:100%; height:auto; border-top: solid 3px red ;border-bottom: solid 3px red; color:red; text-align:center;font-family:tahoma; font-size:18px;'>";
	echo $mensaje;
	echo "</div>";
}
?>
<form name='f1' id='f1' action="?cat=3&sec=36&id_salida=<? echo $_GET['id_salida']; ?>" method="POST">
<input  type="hidden" name="primera" value="1"/>

<table style="width:900px;" id="detalle-prov"  cellpadding="3" cellspacing="4" border="0">

<tr>
<td align="right" colspan="100%">
<a href='?cat=3&sec=34'><img src='img/view_previous.png' width='36px' height='36px' border='0' style='float:right;' class='toolTIP' title='Volver al Listado de Usuarios'></a>
</td>
</tr>
<?
if($mostrar==0)
{
?>

<tr height="30px">
</tr>
 
        <td><label>Producto</label><label style="color:red">(*)</label><br />
        <select name="codbar_productonew"  class="foo" onchange="submit()" 
        >
                <option value=""  class="foo">---</option>
            <?
                $s = "SELECT * FROM productos_new WHERE 1=1 ";
                $r = mysql_query($s,$con);
                
                while($roo = mysql_fetch_assoc($r)){
                    ?>  <option value="<?=$roo['codbar_productonew'];?>"   <? if($_POST['codbar_productonew']==$roo['codbar_productonew']) echo " selected" ;?> class="foo"><?=$roo['descripcion'];?></option> <?    
                }
        
                ?>
            </select>
        </td>
 
        <td><label>Fecha Salida:</label><br/><input size="10" class="foo" type="date" name="fecha_salida" value="<?=$_POST['fecha_salida'];?>"></td>
    </tr>
         <tr>
        <td><label>Cantidad:</label><br/><input size="10" onchange="calcular()" class="foo" type="text" name="cantidad" value="<?=$_POST['cantidad'];?>"
        ></td> 
       
        <td><label>Precio pmp	:</label><br/><input onchange="calcular()" readonly size="10" class="foo" type="text" name="precio_pmp" value="<?=$_POST['precio_pmp'];?>"></td>
        <td><label>Total:</label><br/><input size="10"   readonly="readonly"  class="foo" type="text" name="total" value="<?=$_POST['total'];?>"></td>
    </tr>
    <tr>
    <td>
       
        <label>Bodega</label>          <input  type="radio" name="tipo_salida1"   value="1" onchange="submit()" <? if($_POST['tipo_salida1']==1) echo " checked "; ?>/>  
        <label>Centro Costo</label>    <input  type="radio" name="tipo_salida1"   value="2" onchange="submit()" <? if($_POST['tipo_salida1']==2) echo " checked "; ?>/> 
        </td>
     <td >
     	<?
		  if(!empty($_POST['tipo_salida1'])and ($_POST['tipo_salida1']==1))
		  {
			 $sql=" SELECT * FROM bodegas WHERE rut_empresa='".$_SESSION['empresa']."'";
			 $rec=mysql_query($sql);
			 echo "<select name='cod_bodega'  class='foo' onchange='submit()'>";
			 while($row=mysql_fetch_array($rec))
			 {
				 echo "<option value='".$row['cod_bodega']."' ";
				 if($_POST['cod_bodega']==$row['cod_bodega'])
				 {
				 	echo " selected ";
				 }
				 echo " class='foo' >";
				 echo $row['descripcion_bodega']."</option>";
			 }
			 echo "</select>"; 
		  }
	  
		  if(!empty($_POST['tipo_salida1'])and ($_POST['tipo_salida1']==2))
		  {
			 $sql=" SELECT * FROM centros_costos WHERE rut_empresa='".$_SESSION['empresa']."'";
			 $rec=mysql_query($sql);
			 echo "<select name='id_cc'  class='foo' onchange='submit()'>";
			 while($row=mysql_fetch_array($rec))
			 {
				 echo "<option value='".$row['Id_cc']."' ";
				 if($_POST['id_cc']==$row['Id_cc'])
				 {
				 	echo " selected ";
				 }
				 echo " class='foo' >";
				 echo $row['descripcion_cc']."</option>";
			 }
			 echo "</select>"; 
		  }
        ?>
     </td>
     
    </tr>
         <tr>
    <td>
       
        <label>Activo</label>          <input  type="radio" name="tipo_salida2"   value="1" onchange="submit()" <? if($_POST['tipo_salida2']==1) echo " checked "; ?>/>  
        <label>Lugar Fisico</label>    <input  type="radio" name="tipo_salida2"   value="2" onchange="submit()" <? if($_POST['tipo_salida2']==2) echo " checked "; ?>/> 
        <label>Orden </label>          <input  type="radio" name="tipo_salida2"   value="3" onchange="submit()" <? if($_POST['tipo_salida2']==3) echo " checked "; ?>/> 
        </td>
     <td >
     	<?
		  if(!empty($_POST['tipo_salida2'])and ($_POST['tipo_salida2']==1))
		  {
			 $sql=" SELECT * FROM productos WHERE rut_empresa='".$_SESSION['empresa']."'";
			 $rec=mysql_query($sql);
			 echo "<select name='cod_producto'  class='foo' onchange='submit()'>";
			 			 echo "<option value='0'>Seleccione Producto</option>";
			 while($row=mysql_fetch_array($rec))
			 {
				 echo "<option value='".$row['cod_producto']."' ";
				 if($_POST['cod_producto']==$row['cod_producto'])
				 {
				 	echo " selected ";
				 }
				 echo " class='foo' >";
				 echo $row['descripcion']."</option>";
			 }
			 echo "</select>"; 
		  }
		  

		  
		  if(!empty($_POST['tipo_salida2'])and ($_POST['tipo_salida2']==2))
		  {
			 $sql=" SELECT * FROM lugares_fisicos WHERE rut_empresa='".$_SESSION['empresa']."'";
			 $rec=mysql_query($sql);
			 echo "<select name='id_lf'  class='foo' onchange='submit()'>";
			 while($row=mysql_fetch_array($rec))
			 {
				 echo "<option value='".$row['id_lf']."' ";
				 if($_POST['id_lf']==$row['id_lf'])
				 {
				 	echo " selected ";
				 }
				 echo " class='foo' >";
				 echo $row['descripcion_lf']."</option>";
			 }
			 echo "</select>"; 
		  }
		  
		  if(!empty($_POST['tipo_salida2'])and ($_POST['tipo_salida2']==3))
		  {
			 $sql=" SELECT * FROM cabeceras_ot WHERE rut_empresa='".$_SESSION['empresa']."'";
			 $rec=mysql_query($sql);
			 echo "<select name='id_ot'  class='foo' onchange='submit()'>";
			 while($row=mysql_fetch_array($rec))
			 {
				 echo "<option value='".$row['id_ot']."' ";
				 if($_POST['id_ot']==$row['id_ot'])
				 {
				 	echo " selected ";
				 }
				 echo " class='foo' >";
				 echo $row['descripcion_ot']."</option>";
			 }
			 echo "</select>"; 
		  }
        ?>
     </td>
     <td>
     <?
     	if(!empty($_POST['cod_producto'])&&($_POST['tipo_salida2'])==1)
		{
			
				 $sql=" SELECT * FROM detalles_productos WHERE rut_empresa='".$_SESSION['empresa']."'";
				 $rec=mysql_query($sql);
				 echo "<select name='cod_detalle_producto'  class='foo' onchange='submit()'>";
				 echo "<option value='0'>Seleccione Patente</option>";
				 while($row=mysql_fetch_array($rec))
				 {
					 echo "<option value='".$row['cod_detalle_producto']."' ";
					 if($_POST['cod_detalle_producto']==$row['cod_detalle_producto'])
					 {
						echo " selected ";
					 }
					 echo " class='foo' >";
					 echo $row['patente']."</option>";
				 }
				 echo "</select>";
		}
		?>
     </td>
    </tr>
     
          <tr>
        <td colspan="100%"><label>Observaciones:</label><br/><input size="20"  class="foo" type="text" name="observaciones" value="<?=$_POST['observaciones'];?>"
         style=' width:400px;' ></td> 

    </tr>
    
    
        <tr>
       <td style="text-align: right;"  colspan="100%"><input name="accion" type="submit" value="Grabar"  style="background-color:#006; color:#fff; font-size:12px; font-family:Tahoma, Geneva, sans-serif; margin-right:5px; width:100px; height:25px; border-radius:0.5em;"></td>
   <tr>
			<td colspan="100%" style='text-align:Center;text-align:center;font-family:tahoma;;color:red;font-size:15px;font-weight:bold;' >
				(*) Campos de Ingreso Obligatorio.
			</td>
	</tr>
</table>

<?
	}
?>
</table>
</form>