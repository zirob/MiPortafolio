<?php
//AL PRINCIPIO COMPRUEBO SI HICIERON CLICK EN ALGUNA PÁGINA
if(isset($_GET['page'])){
    $page= $_GET['page'];
}else{
//SI NO DIGO Q ES LA PRIMERA PÁGINA
    $page=1;
}

//ACA SE SELECCIONAN TODOS LOS DATOS DE LA TABLA
$consulta = "SELECT p.*,df.descripcion_familia ,ds.descripcion_subfamilia   FROM productos_new p , familia df, subfamilia ds
WHERE  p.rut_empresa='".$_SESSION['empresa']."' AND  df.id_familia=p.id_familia AND ds.id_subfamilia=p.id_subfamilia ";
$datos=mysql_query($consulta,$con);

//MIRO CUANTOS DATOS FUERON DEVUELTOS
$num_rows=mysql_num_rows($datos);

//ACA SE DECIDE CUANTOS RESULTADOS MOSTRAR POR PÁGINA , EN EL EJEMPLO PONGO 15
$rows_per_page= 20;

//CALCULO LA ULTIMA PÁGINA
$lastpage= ceil($num_rows / $rows_per_page);

//COMPRUEBO QUE EL VALOR DE LA PÁGINA SEA CORRECTO Y SI ES LA ULTIMA PÁGINA
$page=(int)$page;
if($page > $lastpage){
    $page= $lastpage;
}
if($page < 1){
    $page=1;
}

//CREO LA SENTENCIA LIMIT PARA AÑADIR A LA CONSULTA QUE DEFINITIVA
$limit= 'LIMIT '. ($page -1) * $rows_per_page . ',' .$rows_per_page;

//Consulta que contiene el sql
$msg="";
$error="";

$sql ="SELECT p.*,df.descripcion_familia ,ds.descripcion_subfamilia   FROM productos_new p , familia df, subfamilia ds
WHERE  p.rut_empresa='".$_SESSION['empresa']."' AND  df.id_familia=p.id_familia AND ds.id_subfamilia=p.id_subfamilia ";




//Filtros
if(!empty($_POST['codbar_productonew']))
$sql.=" AND p.codbar_productonew like'%".$_POST['codbar_productonew']."%' ";

if(!empty($_POST['descripcion']))
$sql.=" AND p.descripcion like'%".$_POST['descripcion']."%' ";

if(!empty($_POST['codigo_interno']))
$sql.=" AND p.codigo_interno like'%".$_POST['codigo_interno']."%' ";


if(!empty($_POST['descripcion_familia']))
$sql.=" AND df.descripcion_familia like'%".$_POST['descripcion_familia']."%' ";


if(!empty($_POST['descripcion_subfamilia']))
$sql.=" AND ds.descripcion_subfamilia like'%".$_POST['descripcion_subfamilia']."%' ";


if(!empty($_POST['pasillo']))
$sql.=" AND p.pasillo like'%".$_POST['pasillo']."%' ";

if(!empty($_POST['casillero']))
$sql.=" AND p.casillero like'%".$_POST['casillero']."%' ";

if(!empty($_POST['observaciones']))
$sql.=" AND p.observaciones like'%".$_POST['observaciones']."%' ";


$sql.=" AND 1=1 ";
$sql.= " ".$limit;




//Efectua la Consulta
$res = mysql_query($sql,$con);
?>
    <style>
	.fo
	{
		border:1px solid #09F;
		background-color:#FFFFFF;
		color:#000066;
		font-size:11px;
		font-family:Tahoma, Geneva, sans-serif;
		width:80%;
		text-align:center;
	}
	
    /* -------------------------------------------- */
/* ----------- Pagination: Digg Style --------- */
/* -------------------------------------------- */
ul    { border:0; margin:0; padding:0; }
#pagination-digg li          { border:0; margin:0; padding:0; font-size:11px; list-style:none; /* savers */ float:left; }
#pagination-digg a           { border:solid 1px #9aafe5; margin-right:2px; }
#pagination-digg .previous-off,
#pagination-digg .next-off   { border:solid 1px #DEDEDE; color:#888888; display:block; float:left; font-weight:bold; margin-right:2px; padding:3px 4px; }
#pagination-digg .next a,
#pagination-digg .previous a { font-weight:bold; }
#pagination-digg .active     { background:#2e6ab1; color:#FFFFFF; font-weight:bold; display:block; float:left; padding:4px 6px; /* savers */ margin-right:2px; }
#pagination-digg a:link,
#pagination-digg a:visited   { color:#0e509e; display:block; float:left; padding:3px 6px; text-decoration:none; }
#pagination-digg a:hover     { border:solid 1px #0e509e; }
	</style>
    <br /><br />
    <form action="?cat=3&sec=3&filtro=1" method="POST">
    <table width="95%">
        <tr>
        <td id="list_link"  colspan="100%"><a href="?cat=3&sec=31"><img src="img/add1.png" width="36px" height="36px" border="0" class="toolTIP" title="Agregar Bodega"></a></td>
    
    </tr>
    </table>
<table id="list_registros" style=" border-collapse:collapse" border="1" >

    <tr  style='font-family:tahoma;font-size:12px;'>
        <td style="text-align:left; font-weight:bold; ">Filtro:</td>
        <td style="text-align:center"><input name='codbar_productonew' value='<? echo $_POST['codbar_productonew']?>' class="fo" style="width:50px;"></td>
        <td style="text-align:center">
        <input name='descripcion' value='<? echo $_POST['descripcion']?>' class="fo" style="width:50px;">   
        </td>
        <td style="text-align:center">
       <input name='codigo_interno' value='<? echo $_POST['codigo_interno']?>' class="fo" style="width:50px;">
        </td>
        
         <td style="text-align:center">
		<input name='descripcion_familia' value='<? echo $_POST['descripcion_familia']?>' class="fo" style="width:50px;">
        </td>
        
        <td style="text-align:center">
        <input name='descripcion_subfamilia' value='<? echo $_POST['descripcion_subfamilia']?>' class="fo" style="width:50px;">
        </td>
        
        <td style="text-align:center">
        <input name='pasillo' value='<? echo $_POST['pasillo']?>' class="fo" style="width:50px;">
        </td>
        
        <td style="text-align:center">
        <input name='casillero' value='<? echo $_POST['casillero']?>' class="fo" style="width:50px;">
        </td>
        
        <td style="text-align:center">
        <input name='observaciones' value='<? echo $_POST['observaciones']?>' class="fo" style="width:100px;">
        </td>
    	
        <td style="text-align:right" colspan="4"><input type="Submit" value="Filtrar" style="background-color:#006; color:#fff; font-size:12px; font-family:Tahoma, Geneva, sans-serif; margin-right:5px; width:100px; height:25px; border-radius:0.5em;"></td>
    </tr>
    <tr  style="background-color:rgb(0,0,255); color:rgb(255,255,255); font-family:Tahoma; font-size:12px;">
        <td style="text-align:center; ">#</td>
        <td style="text-align:center; ">Codigo de<br /> Barras</td>
        <td style="text-align:center">Descripción</td>
        <td style="text-align:center">Código Interno</td>
        <td style="text-align:center">Familia</td>
        <td style="text-align:center">SubFamilia</td>
        <td style="text-align:center">Pasillo</td>
        <td style="text-align:center">Casillero</td>
        <td style="text-align:center">Observación</td>
        <td style="text-align:center">Editar</td>
        <td style="text-align:center">Ver</td>
        <td style="text-align:center">Entradas</td>
        <td style="text-align:center">Salidas</td>
        <!--<td width="100px">Editar</td> -->
    </tr>    

<?

	//Desempilamos los datos
	$i=1;
	while($row=mysql_fetch_array($res))
	{
    echo "<tr   style='font-family:tahoma;font-size:12px;'>";
    echo "    <td style='text-align:center'>".$i++."</td>";
    echo "    <td style='text-align:center'>".$row['codbar_productonew']."</td>";
    echo "    <td style='text-align:center'>".$row['descripcion']."</td>";
    echo "    <td style='text-align:center'>".$row['codigo_interno']."</td>";
	echo "    <td style='text-align:center'>".$row['descripcion_familia']."</td>";
    echo "    <td style='text-align:center' >".$row['descripcion_subfamilia']."</td>";
    echo "    <td style='text-align:center'>".$row['pasillo']."</td>";
	echo "    <td style='text-align:center'>".$row['casillero']."</td>";
    echo "    <td style='text-align:center' >".$row['observaciones']."</td>";
	echo "    <td style='text-align: center;'>
				    <a href='?cat=3&sec=31&action=2&codbar_productonew=".$row['codbar_productonew']."' >
					    <img src='img/edit.png' width='24px' height='24px' border='0' class='toolTIP' title='Editar Producto'>
					</a>
				</td>";
	echo "    <td style='text-align: center;'>
				    <a href='?cat=3&sec=32&action=2&codbar_productonew=".$row['codbar_productonew']."' >
					    <img src='img/view.png' width='24px' height='24px' border='0' class='toolTIP' title='Ver Producto'>
					</a>
				</td>";
	echo "    <td style='text-align: center;'>
				    <a href='?cat=3&sec=33&action=2&codbar_productonew=".$row['codbar_productonew']."' >
					    <img src='img/document_add.png' width='24px' height='24px' border='0' class='toolTIP' title='Ver Producto'>
					</a>
				</td>";
	echo "    <td style='text-align: center;'>
				    <a href='?cat=3&sec=34&action=2&codbar_productonew=".$row['codbar_productonew']."' >
					    <img src='img/disk_blue_ok.png' width='24px' height='24px' border='0' class='toolTIP' title='Ver Producto'>
					</a>
				</td>";
    echo "</tr>";
	}
 ?>


</table>
</form>
<table width="900px" align="center" border="0" >
<tr>
    <td>
<?

//UNA VEZ Q MUESTRO LOS DATOS TENGO Q MOSTRAR EL BLOQUE DE PAGINACIÓN SIEMPRE Y CUANDO HAYA MÁS DE UNA PÁGINA
if($num_rows != 0){
   $nextpage= $page +1;
   $prevpage= $page -1;

?><ul id="pagination-digg"><?
//SI ES LA PRIMERA PÁGINA DESHABILITO EL BOTON DE PREVIOUS, MUESTRO EL 1 COMO ACTIVO Y MUESTRO EL RESTO DE PÁGINAS
 if ($page == 1) {
    ?>
      <li class="previous-off">&laquo; Previous</li>
      <li class="active">1</li> <?
    for($i= $page+1; $i<= $lastpage ; $i++){?>
            <li><a href="?&cat=3&sec=15&page=<? echo $i;?>"><? echo $i;?></a></li>
 <? } 

 //Y SI LA ULTIMA PÁGINA ES MAYOR QUE LA ACTUAL MUESTRO EL BOTON NEXT O LO DESHABILITO
    if($lastpage >$page ){?>       
      <li class="next"><a href="?&cat=3&sec=15&page=<? echo $nextpage;?>" >Next &raquo;</a></li><?
    }else{?>
      <li class="next-off">Next &raquo;</li>
<?  }
} else {
    //EN CAMBIO SI NO ESTAMOS EN LA PÁGINA UNO HABILITO EL BOTON DE PREVIUS Y MUESTRO LAS DEMÁS
    ?>
      <li class="previous"><a href="?&cat=3&sec=15&page=<? echo $prevpage;?>"  >&laquo; Previous</a></li><?
      for($i= 1; $i<= $lastpage ; $i++){
            //COMPRUEBO SI ES LA PÁGINA ACTIVA O NO
            if($page == $i){
        ?>  <li class="active"><? echo $i;?></li><?
            }else{
        ?>  <li><a href="?&cat=3&sec=15&page=<? echo $i;?>" ><? echo $i;?></a></li><?
            }
      }
         //SI NO ES LA ÚLTIMA PÁGINA ACTIVO EL BOTON NEXT    
      if($lastpage >$page ){    ?> 
      <li class="next"><a href="?&cat=3&sec=15&page=<? echo $nextpage;?>">Next &raquo;</a></li><?
      }else{
    ?> <li class="next-off">Next &raquo;</li><?
      }
 }   
?></ul></div><?
}
?>
 </td>
</tr>

</table>