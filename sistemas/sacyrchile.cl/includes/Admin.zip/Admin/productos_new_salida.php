<?php
//AL PRINCIPIO COMPRUEBO SI HICIERON CLICK EN ALGUNA PÁGINA
if(isset($_GET['page'])){
    $page= $_GET['page'];
}else{
//SI NO DIGO Q ES LA PRIMERA PÁGINA
    $page=1;
}

//ACA SE SELECCIONAN TODOS LOS DATOS DE LA TABLA
$consulta = "SELECT p.*,c.descripcion_cc,b.descripcion_bodega,l.descripcion_lf,pp.descripcion FROM  ((((productos_new_salidas  
  p LEFT JOIN centros_costos c ON p.id_cc=c.id_cc) LEFT JOIN bodegas b ON b.cod_bodega=p.cod_bodega)
   LEFT JOIN lugares_fisicos l ON p.id_lf=l.id_lf) LEFT JOIN productos pp ON p.cod_producto=pp.cod_producto) WHERE 1=1 ";
$datos=mysql_query($consulta,$con);

//MIRO CUANTOS DATOS FUERON DEVUELTOS
$num_rows=mysql_num_rows($datos);

//ACA SE DECIDE CUANTOS RESULTADOS MOSTRAR POR PÁGINA , EN EL EJEMPLO PONGO 15
$rows_per_page= 20;

//CALCULO LA ULTIMA PÁGINA
$lastpage= ceil($num_rows / $rows_per_page);

//COMPRUEBO QUE EL VALOR DE LA PÁGINA SEA CORRECTO Y SI ES LA ULTIMA PÁGINA
$page=(int)$page;
if($page > $lastpage){
    $page= $lastpage;
}
if($page < 1){
    $page=1;
}

//CREO LA SENTENCIA LIMIT PARA AÑADIR A LA CONSULTA QUE DEFINITIVA
$limit= 'LIMIT '. ($page -1) * $rows_per_page . ',' .$rows_per_page;


if($_GET['id_salida'])
{
	$fecha=date("Y-m-d H:i:s");
	$sql =" UPDATE productos_new_salidas SET ";
	$sql.=" estado_salida=2,";
	$sql.=" usuario_elimina='".$_SESSION['user']."',";
	$sql.=" fecha_elimina='".$fecha."'";
	$sql.=" WHERE id_salida=".$_GET['id_salida']." AND rut_empresa='".$_SESSION['empresa']."'";
	mysql_query($sql);
	echo "<div style=' width:100%; height:auto; border-top: solid 3px blue;border-bottom: solid 3px blue;color:blue; text-align:center; font-family:tahoma; font-size:18px;'>";
	echo "Eliminacion correcta de la salida n:".$_GET['id_salida'];
	echo "</div>";
}

//Consulta que contiene el sql
$msg="";
$error="";

/*
$sql ="SELECT p.*,c.descripcion_cc,b.descripcion_bodega,l.descripcion_lf,pp.descripcion
 FROM productos_new_salidas p ,centros_costos c ,bodegas b,lugares_fisicos l,productos pp
  WHERE 1=1 AND p.id_cc=c.id_cc AND b.cod_bodega=p.cod_bodega AND p.id_lf=l.id_lf AND p.cod_producto=pp.cod_producto ";*/
  
  $sql=" SELECT p.*,c.descripcion_cc,b.descripcion_bodega,l.descripcion_lf,pp.descripcion FROM  ((((productos_new_salidas  
  p LEFT JOIN centros_costos c ON p.id_cc=c.id_cc) LEFT JOIN bodegas b ON b.cod_bodega=p.cod_bodega)
   LEFT JOIN lugares_fisicos l ON p.id_lf=l.id_lf) LEFT JOIN productos pp ON p.cod_producto=pp.cod_producto) WHERE 1=1 ";


//Filtros
if(!empty($_POST['fecha_salida']))
{
	$fecha_factura=($_POST['fecha_salida']);
	$sql.=" AND p.fecha_salida like'%".$fecha_factura."%' ";
}

if(!empty($_POST['cantidad']))
$sql.=" AND p.cantidad like'%".$_POST['cantidad']."%' ";


if(!empty($_POST['descripcion_cc']))
$sql.=" AND c.descripcion_cc like'%".$_POST['descripcion_cc']."%' ";


if(!empty($_POST['descripcion_bodega']))
$sql.=" AND b.descripcion_bodega like'%".$_POST['descripcion_bodega']."%' ";


if(!empty($_POST['descripcion']))
$sql.=" AND pp.descripcion like'%".$_POST['descripcion']."%' ";



if(!empty($_POST['descripcion_lf']))
$sql.=" AND l.descripcion_lf like'%".$_POST['descripcion_lf']."%' ";


if(!empty($_POST['id_ot']))
$sql.=" AND p.id_ot like'%".$_POST['id_ot']."%' ";

if(!empty($_POST['observaciones']))
$sql.=" AND p.observaciones like'%".$_POST['observaciones']."%' ";


$sql.=" AND 1=1 ";
$sql.= " ".$limit;




//Efectua la Consulta
$res = mysql_query($sql,$con);
?>
    <style>
	.fo
	{
		border:1px solid #09F;
		background-color:#FFFFFF;
		color:#000066;
		font-size:11px;
		font-family:Tahoma, Geneva, sans-serif;
		width:80%;
		text-align:center;
	}
	
    /* -------------------------------------------- */
/* ----------- Pagination: Digg Style --------- */
/* -------------------------------------------- */
ul    { border:0; margin:0; padding:0; }
#pagination-digg li          { border:0; margin:0; padding:0; font-size:11px; list-style:none; /* savers */ float:left; }
#pagination-digg a           { border:solid 1px #9aafe5; margin-right:2px; }
#pagination-digg .previous-off,
#pagination-digg .next-off   { border:solid 1px #DEDEDE; color:#888888; display:block; float:left; font-weight:bold; margin-right:2px; padding:3px 4px; }
#pagination-digg .next a,
#pagination-digg .previous a { font-weight:bold; }
#pagination-digg .active     { background:#2e6ab1; color:#FFFFFF; font-weight:bold; display:block; float:left; padding:4px 6px; /* savers */ margin-right:2px; }
#pagination-digg a:link,
#pagination-digg a:visited   { color:#0e509e; display:block; float:left; padding:3px 6px; text-decoration:none; }
#pagination-digg a:hover     { border:solid 1px #0e509e; }
	</style>
    <br /><br />
    <form action="?cat=3&sec=34&filtro=1" method="POST">
    <table width="95%">
        <tr>
        <td id="list_link"  colspan="100%"><a href="?cat=3&sec=36"><img src="img/add1.png" width="36px" height="36px" border="0" class="toolTIP" title="Agregar Salida"></a></td>
    
    </tr>
    </table>
<table id="list_registros" style=" border-collapse:collapse" border="1" >

    <tr  style='font-family:tahoma;font-size:12px;'>
        <td style="text-align:left; font-weight:bold; ">Filtro:</td>
        <td style="text-align:center">
        <input type="date" name='fecha_salida' value='<? echo $_POST['fecha_salida']?>' class="fo" style="width:100px;">   
        </td>
        <td style="text-align:center">
       <input name='cantidad' value='<? echo $_POST['cantidad']?>' class="fo" style="width:50px;">
        </td>
        
         <td style="text-align:center">
		<input name='descripcion_cc' value='<? echo $_POST['descripcion_cc']?>' class="fo" style="width:100px;">
        </td>
        
        <td style="text-align:center">
        <input name='descripcion_bodega' value='<? echo $_POST['descripcion_bodega']?>' class="fo" style="width:100px;">
        </td>
        
        <td style="text-align:center">
        <input name='descripcion' value='<? echo $_POST['descripcion']?>' class="fo" style="width:50px;">
        </td>
        
        <td style="text-align:center">
        <input name='descripcion_lf' value='<? echo $_POST['descripcion_lf']?>' class="fo" style="width:100px;">
        </td>
        
        <td style="text-align:center">
        <input type="text" name='id_ot' value='<? echo $_POST['id_ot']?>' class="fo" style="width:100px;">
        </td>
        <td style="text-align:center">
        <input type="text" name='observaciones' value='<? echo $_POST['observaciones']?>' class="fo" style="width:100px;">
        </td>
    	
        <td style="text-align:right" colspan="4"><input type="Submit" value="Filtrar" style="background-color:#006; color:#fff; font-size:12px; font-family:Tahoma, Geneva, sans-serif; margin-right:5px; width:100px; height:25px; border-radius:0.5em;"></td>
    </tr>
    <tr  style="background-color:rgb(0,0,255); color:rgb(255,255,255); font-family:Tahoma; font-size:12px;">
        <td style="text-align:center; ">#</td>
        <td style="text-align:center; ">Fecha Salida</td>
        <td style="text-align:center">Cantidad</td>
        <td style="text-align:center">Centro Costos</td>
        <td style="text-align:center">Bodegas</td>
        <td style="text-align:center">Activo</td>
        <td style="text-align:center">Lugar Físico</td>
        <td style="text-align:center">Nº O.T.</td>
        <td style="text-align:center">Observaciones</td>
        <td style="text-align:center">Editar</td>
        <td style="text-align:center">Eliminar</td>
       <!-- <td style="text-align:center" colspan="2">Editar</td>
        <!--<td width="100px">Editar</td> -->
    </tr>    

<?

	//Desempilamos los datos
	$i=1;
	while($row=mysql_fetch_array($res))
	{
    echo "<tr   style='font-family:tahoma;font-size:12px;'>";
    echo "    <td style='text-align:center'>".$i++."</td>";
    echo "    <td style='text-align:center'>".$row['fecha_salida']."</td>";
    echo "    <td style='text-align:center'>".$row['cantidad']."</td>";
    echo "    <td style='text-align:center'>".$row['descripcion_cc']."</td>";
	echo "    <td style='text-align:center'>".$row['descripcion_bodega']."</td>";
    echo "    <td style='text-align:center' >".$row['descripcion']."</td>";
    echo "    <td style='text-align:center'>".$row['descripcion_lf']."</td>";
	echo "    <td style='text-align:center'>".$row['id_ot']."</td>";
	echo "    <td style='text-align:center'>".$row['observaciones']."</td>";

	echo "    <td style='text-align: center;'>
				    <a href='?cat=3&sec=36&action=2&id_salida=".$row['id_salida']."' >
					    <img src='img/edit.png' width='24px' height='24px' border='0' class='toolTIP' title='Editar Entrada'>
					</a>
				</td>";
		echo "    <td style='text-align: center;'>
				    <a href='?cat=3&sec=34&action=2&id_salida=".$row['id_salida']."' >
					    <img src='img/eliminar.png' width='24px' height='24px' border='0' class='toolTIP' title='Eliminar Entrada'>
					</a>
				</td>";
    echo "</tr>";
	}
 ?>


</table>
</form>
<br>
<table width="900px" align="center" border="0" >
<tr>
    <td>
<?

//UNA VEZ Q MUESTRO LOS DATOS TENGO Q MOSTRAR EL BLOQUE DE PAGINACIÓN SIEMPRE Y CUANDO HAYA MÁS DE UNA PÁGINA
if($num_rows != 0){
   $nextpage= $page +1;
   $prevpage= $page -1;

?><ul id="pagination-digg"><?
//SI ES LA PRIMERA PÁGINA DESHABILITO EL BOTON DE PREVIOUS, MUESTRO EL 1 COMO ACTIVO Y MUESTRO EL RESTO DE PÁGINAS
 if ($page == 1) {
    ?>
      <li class="previous-off">&laquo; Previous</li>
      <li class="active">1</li> <?
    for($i= $page+1; $i<= $lastpage ; $i++){?>
            <li><a href="?&cat=3&sec=34&page=<? echo $i;?>"><? echo $i;?></a></li>
 <? } 

 //Y SI LA ULTIMA PÁGINA ES MAYOR QUE LA ACTUAL MUESTRO EL BOTON NEXT O LO DESHABILITO
    if($lastpage >$page ){?>       
      <li class="next"><a href="?&cat=3&sec=34&page=<? echo $nextpage;?>" >Next &raquo;</a></li><?
    }else{?>
      <li class="next-off">Next &raquo;</li>
<?  }
} else {
    //EN CAMBIO SI NO ESTAMOS EN LA PÁGINA UNO HABILITO EL BOTON DE PREVIUS Y MUESTRO LAS DEMÁS
    ?>
      <li class="previous"><a href="?&cat=3&sec=34&page=<? echo $prevpage;?>"  >&laquo; Previous</a></li><?
      for($i= 1; $i<= $lastpage ; $i++){
            //COMPRUEBO SI ES LA PÁGINA ACTIVA O NO
            if($page == $i){
        ?>  <li class="active"><? echo $i;?></li><?
            }else{
        ?>  <li><a href="?&cat=3&sec=34&page=<? echo $i;?>" ><? echo $i;?></a></li><?
            }
      }
         //SI NO ES LA ÚLTIMA PÁGINA ACTIVO EL BOTON NEXT    
      if($lastpage >$page ){    ?> 
      <li class="next"><a href="?&cat=3&sec=34&page=<? echo $nextpage;?>">Next &raquo;</a></li><?
      }else{
    ?> <li class="next-off">Next &raquo;</li><?
      }
 }   
?></ul></div><?
}
?>
 </td>
</tr>

</table>